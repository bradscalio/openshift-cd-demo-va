package org.jboss.as.quickstarts.tasksrs.category;

public interface UnitTest {
}
